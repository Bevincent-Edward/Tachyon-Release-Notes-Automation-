---
title: Fee Waiver Option in Agent Center

description: Fee waiver option in Agent Center is added to allow agents to waive non‑late fees.

tag: Agent Center

hideAsideIntro: true

---

# Fee Waiver Option in Agent Center

{{< tag >}}

## Problem statement

Agent Center platform lacks the ability to waive fees other than late payment fees.

## Enhancement

Adds the ability to waive all applicable fees and charges from the quick command window.

Filters fees by type, enabling agents to select specific fees for partial or complete waiver.

## Impact

Allows agents to complete fee and charge waivers directly in Agent Center.

Enables agents to retrieve required fees or charges faster using added filters.

## User interface changes

Waive Fee feature from quick commands is enhanced to support all the applicable fees and charges

## Audit logs

Disabled
