---
title: **EoD** Notifications in **EoD** Center

description: **EoD** notifications are added to the **EoD** Center to inform operations personnel of phase changes.

tag: EOD Center

hideAsideIntro: true

---

# **EoD** Notifications in **EoD** Center

{{< tag >}}

## Problem statement

Phase changes are not notified to operations personnel.

## Enhancement

The system schedules email triggers to track phase changes.

An SOP is published with event details and configuration steps to set up emails for phase changes on Notification Center.

## Impact

Operations team receives timely updates without manual checks.

Operations team can track phase changes through email notifications.

## Audit logs

Disabled
