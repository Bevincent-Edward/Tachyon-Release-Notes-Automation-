---
title: Reversal Indicator for Original Transactions Only

description: Reversal indicator is enhanced to appear only on original transactions.

tag: Revolving Credit Account Work Bench

hideAsideIntro: true

---

# Reversal Indicator for Original Transactions Only

{{< tag >}}

## Problem statement

Reversal indicator appears for both original and reversed transactions, causing confusion.

## Enhancement

Reversal indicator appears only on the original transaction.

## Impact

This change allows users to quickly determine if a transaction has been reversed.

## User interface changes

Reversal indicator is now present only on original debit transactions.

## Audit logs

Disabled
