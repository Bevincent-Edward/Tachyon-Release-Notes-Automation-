---
title: Bulk Notification Triggering in Account Holder Workbench

description: Bulk notification triggering is introduced in the Account holder workbench to allow users to send ad hoc notifications in bulk.

tag: Account holder workbench

hideAsideIntro: true

---

# Bulk Notification Triggering in Account Holder Workbench

{{< tag >}}

## Problem statement

The system does not support sending bulk ad hoc notifications, requiring users to rely on third‑party solutions.

## Enhancement

The capability to send bulk ad hoc notifications through the Operations Center is added.

## Impact

This enhancement significantly improves operational efficiency by reducing manual workload and turnaround time when triggering ad hoc notifications.

## Audit logs

Disabled
