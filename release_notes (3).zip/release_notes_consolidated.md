# Release Notes

## Geography segregation

| Geography | Features |
|-----------|----------|
| All | Reversal Indicator for Original Transactions Only, Posting Summary Simplification in Support Center, Support Status Tracking for Ruby Final Closure Workflow, Configurable Value Date for Interest Computation, Reason Code Capture for Replace Renew Reissue Actions, Financial Profile Expansion for Account Holders, Bulk Notification Triggering in Account Holder Workbench, Fee Waiver Option in Agent Center, Memo Enhancements On Agent Center Home, Discretionary DebitCredit Recording in Financial Accounting Workbench, **EoD** Notifications in **EoD** Center, Checklist Enhancements in **EoD** Center |
| India | Reversal Indicator for Original Transactions Only, Posting Summary Simplification in Support Center, Support Status Tracking for Ruby Final Closure Workflow, Configurable Value Date for Interest Computation, Reason Code Capture for Replace Renew Reissue Actions, Financial Profile Expansion for Account Holders, Bulk Notification Triggering in Account Holder Workbench, Fee Waiver Option in Agent Center, Memo Enhancements On Agent Center Home, Discretionary DebitCredit Recording in Financial Accounting Workbench, **EoD** Notifications in **EoD** Center, Checklist Enhancements in **EoD** Center |
| US | Reversal Indicator for Original Transactions Only, Posting Summary Simplification in Support Center, Support Status Tracking for Ruby Final Closure Workflow, Configurable Value Date for Interest Computation, Reason Code Capture for Replace Renew Reissue Actions, Financial Profile Expansion for Account Holders, Bulk Notification Triggering in Account Holder Workbench, Fee Waiver Option in Agent Center, Memo Enhancements On Agent Center Home, Discretionary DebitCredit Recording in Financial Accounting Workbench, **EoD** Notifications in **EoD** Center, Checklist Enhancements in **EoD** Center |

---

## All geographies

### Reversal Indicator for Original Transactions Only

{{< tag >}}

#### Problem statement

Reversal indicator appears for both original and reversed transactions, causing confusion.

#### Enhancement

Reversal indicator appears only on the original transaction.

#### Impact

This change allows users to quickly determine if a transaction has been reversed.

#### User interface changes

Reversal indicator is now present only on original debit transactions.

#### Audit logs

Disabled

---

### Posting Summary Simplification in Support Center

{{< tag >}}

#### Problem statement

The Posting Summary section in the Support Center displays detailed metrics that issuers prefer not to show.

#### Enhancement

The detailed metrics section is removed from the Posting Summary.

#### Impact

Allows users to focus on summary and graphical data without confusion.

#### User interface changes

Detailed metrics table is not present in Postings Summary section.

#### Audit logs

Disabled

---

### Support Status Tracking for Ruby Final Closure Workflow

{{< tag >}}

#### Problem statement

The final account closure workflow emits events only when closure succeeds, so downstream systems cannot detect in-progress, failed, or blocked states.

#### Enhancement

A new CLOSURE_FAILED event is emitted during closure failures on the same topic, providing structured failure metadata.

#### Impact

Consumers can reliably track the full lifecycle of final closure, including failures, and update status, bundles, or dependent flows accordingly.

#### Known issues and callouts

SPB-8049 (will be taken up as a CR)

#### Audit logs

Disabled

---

### Configurable Value Date for Interest Computation

{{< tag >}}

#### Problem statement

Only the value date is considered for interest computation, preventing issuers from setting alternative start dates such as cycle start or posting dates.

#### Enhancement

Value Date Decision Policy is added, allowing issuers to define interest value date behavior per transaction type using posting attributes, voucher codes, and precedence rules.

#### Impact

Issuers gain precise control over interest accrual start dates across diverse transaction scenarios, improving regulatory compliance and accuracy of interest calculations.

#### User interface changes

Yes, in the Postings tab in Operations Center and Support Center a new column Statement Date which displays the transaction date is also added.

#### Known issues and callouts

https://zeta-saas.atlassian.net/browse/SPQ-22149

#### Audit logs

Disabled

---

### Reason Code Capture for Replace Renew Reissue Actions

{{< tag >}}

#### Problem statement

The reason for closing a source card during Replace, Reissue, or Renew actions is not captured in Individual or Bulk Request Definitions, limiting traceability for **OPS** and Risk teams.

#### Enhancement

Added backend support for sourceCardDeletionReason in Reissue and Renew APIs, enabling both Individual and Bulk RDs to capture, validate, and pass the reason code to Aether and downstream systems.

#### Impact

**OPS** users can select and record standardized reason codes for all RRR actions. The captured reason will be stored, audit-logged, and displayed in the Bundle Overview → Bundle Artefacts table for better visibility and reporting.

#### User interface changes

Ops Center

#### Known issues and callouts

Below Reason code segregation for Replace, Renew and Reissue is not available in Bulk flow. [example Bulk renew will accept Reason code as Lost] 
reference Bug: SPB-8124
Reason code segregation is available only in single flow - Renew, Reissue, Replace dropdown.
Open Screenshot 2025-12-04 at 5.53.51 PM.png

#### Audit logs

Enabled

---

### Financial Profile Expansion for Account Holders

{{< tag >}}

#### Problem statement

The account holder schema stores financial details but limits them to income data, preventing capture of assets or expenses.

#### Enhancement

Remodel the financial details object to capture income and expense entries, recording type, frequency, and value.

#### Impact

Allows issuers to provide better product recommendations, faster approvals, and tailored services, reducing repetitive data submissions.

#### User interface changes

Operations Center and Support Center

#### Reports and extracts

Yes

#### Audit logs

Disabled

---

### Bulk Notification Triggering in Account Holder Workbench

{{< tag >}}

#### Problem statement

The system does not support sending bulk ad hoc notifications, requiring users to rely on third‑party solutions.

#### Enhancement

The capability to send bulk ad hoc notifications through the Operations Center is added.

#### Impact

This enhancement significantly improves operational efficiency by reducing manual workload and turnaround time when triggering ad hoc notifications.

#### Audit logs

Disabled

---

### Fee Waiver Option in Agent Center

{{< tag >}}

#### Problem statement

Agent Center platform lacks the ability to waive fees other than late payment fees.

#### Enhancement

Adds the ability to waive all applicable fees and charges from the quick command window.

Filters fees by type, enabling agents to select specific fees for partial or complete waiver.

#### Impact

Allows agents to complete fee and charge waivers directly in Agent Center.

Enables agents to retrieve required fees or charges faster using added filters.

#### User interface changes

Waive Fee feature from quick commands is enhanced to support all the applicable fees and charges

#### Audit logs

Disabled

---

### Memo Enhancements On Agent Center Home

{{< tag >}}

#### Problem statement

Memos hold important contextual information related to customers, but they are not visible on the Agent Center home screen.

#### Enhancement

Memos are pinned to the Agent Center home page in a widget within the account holders details section.

Memos are enhanced to store categories and subcategories for each entry.

#### Impact

Enables agents to fetch customer context from memos on the home screen.

#### User interface changes

Yes

#### Audit logs

Disabled

---

### Discretionary DebitCredit Recording in Financial Accounting Workbench

{{< tag >}}

#### Problem statement

Operations teams lack a standardized, safe, or guided workflow within **FAWB** to post manual adjustments such as refunds, reversals, chargebacks, and dispute-related corrections.

#### Enhancement

The enhancement introduces the following:

- Dedicated console in **FAWB** for recording discretionary debit/credit transactions with safety, validation, and auditability
- CoA selection–driven **UI** activation ensures proper context before data entry
- Voucher Code Dropdown
- Dynamic Form Rendering
- Enhanced Ledger Picker

#### Impact

Allows users to standardize discretionary transactions across all tenants.

Enables agents to perform **OPS**-initiated adjustments through a unified, controlled system.

#### User interface changes

Yes, Operations Center (Optum)

#### Known issues and callouts

Aura API version changes from V3 to V1 for Optum zone

#### Audit logs

Disabled

---

### **EoD** Notifications in **EoD** Center

{{< tag >}}

#### Problem statement

Phase changes are not notified to operations personnel.

#### Enhancement

The system schedules email triggers to track phase changes.

An SOP is published with event details and configuration steps to set up emails for phase changes on Notification Center.

#### Impact

Operations team receives timely updates without manual checks.

Operations team can track phase changes through email notifications.

#### Audit logs

Disabled

---

### Checklist Enhancements in **EoD** Center

{{< tag >}}

#### Problem statement

ATD Checklist filtering lacks refinement, phase naming is inconsistent across views, and sorting logic does not match **EoD** Workers tab priorities.

#### Enhancement

The enhancement introduces the following:

- Updated ATD Checklist criteria to include all non-blocking checklists and removed EOP_PHASE condition
- Renamed Closed phase to EOP across ATD Checklist, **EoD** Checklist, and error/warning banners
- Added phase filter in ATD Checklist view configuration
- Added attribute filter for Business MIS and Execution MIS (IS_BUSINESS_MIS, IS_EOD_EXECUTION_MIS)
- Fixed sorting logic to follow **EoD** Workers tab order with executing phase at the top

#### Impact

The impact of the enhancement is detailed below:

- Allows users to see checklist items with consistent phase naming across all views
- Enables agents to filter checklists by phase and attribute, speeding up identification
- Increases the efficiency of operations by aligning ATD and **EoD** interfaces and improving sorting

#### User interface changes

Yes EOD enter Home screen

#### Audit logs

Disabled

---

