---
title: Memo Enhancements On Agent Center Home

description: Memo Enhancements are introduced to **PIN** memos to the Agent Center home page and add category support.

tag: Agent Center

hideAsideIntro: true

---

# Memo Enhancements On Agent Center Home

{{< tag >}}

## Problem statement

Memos hold important contextual information related to customers, but they are not visible on the Agent Center home screen.

## Enhancement

Memos are pinned to the Agent Center home page in a widget within the account holders details section.

Memos are enhanced to store categories and subcategories for each entry.

## Impact

Enables agents to fetch customer context from memos on the home screen.

## User interface changes

Yes

## Audit logs

Disabled
