---
title: Support Status Tracking for Ruby Final Closure Workflow

description: Support status tracking for Ruby final closure workflow is enhanced to emit failure events.

tag: Revolving Credit Account Processing

hideAsideIntro: true

---

# Support Status Tracking for Ruby Final Closure Workflow

{{< tag >}}

## Problem statement

The final account closure workflow emits events only when closure succeeds, so downstream systems cannot detect in-progress, failed, or blocked states.

## Enhancement

A new CLOSURE_FAILED event is emitted during closure failures on the same topic, providing structured failure metadata.

## Impact

Consumers can reliably track the full lifecycle of final closure, including failures, and update status, bundles, or dependent flows accordingly.

## Known issues and callouts

SPB-8049 (will be taken up as a CR)

## Audit logs

Disabled
