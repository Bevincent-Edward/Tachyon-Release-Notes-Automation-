---
title: Checklist Enhancements in **EoD** Center

description: Checklist visibility is enhanced to provide clearer phase naming and improved filtering.

tag: EOD Centre

hideAsideIntro: true

---

# Checklist Enhancements in **EoD** Center

{{< tag >}}

## Problem statement

ATD Checklist filtering lacks refinement, phase naming is inconsistent across views, and sorting logic does not match **EoD** Workers tab priorities.

## Enhancement

The enhancement introduces the following:

- Updated ATD Checklist criteria to include all non-blocking checklists and removed EOP_PHASE condition
- Renamed Closed phase to EOP across ATD Checklist, **EoD** Checklist, and error/warning banners
- Added phase filter in ATD Checklist view configuration
- Added attribute filter for Business MIS and Execution MIS (IS_BUSINESS_MIS, IS_EOD_EXECUTION_MIS)
- Fixed sorting logic to follow **EoD** Workers tab order with executing phase at the top

## Impact

The impact of the enhancement is detailed below:

- Allows users to see checklist items with consistent phase naming across all views
- Enables agents to filter checklists by phase and attribute, speeding up identification
- Increases the efficiency of operations by aligning ATD and **EoD** interfaces and improving sorting

## User interface changes

Yes EOD enter Home screen

## Audit logs

Disabled
