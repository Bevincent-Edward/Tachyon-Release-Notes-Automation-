---
title: Posting Summary Simplification in Support Center

description: Posting Summary Simplification is introduced to display only summary and graphical representation in the Support Center.

tag: Revolving Credit Account Work Bench

hideAsideIntro: true

---

# Posting Summary Simplification in Support Center

{{< tag >}}

## Problem statement

The Posting Summary section in the Support Center displays detailed metrics that issuers prefer not to show.

## Enhancement

The detailed metrics section is removed from the Posting Summary.

## Impact

Allows users to focus on summary and graphical data without confusion.

## User interface changes

Detailed metrics table is not present in Postings Summary section.

## Audit logs

Disabled
