---
title: Reason Code Capture for Replace Renew Reissue Actions

description: Reason code capture is added to Replace, Renew, and Reissue actions to improve traceability.

tag: Product Bundle Workbench

hideAsideIntro: true

---

# Reason Code Capture for Replace Renew Reissue Actions

{{< tag >}}

## Problem statement

The reason for closing a source card during Replace, Reissue, or Renew actions is not captured in Individual or Bulk Request Definitions, limiting traceability for **OPS** and Risk teams.

## Enhancement

Added backend support for sourceCardDeletionReason in Reissue and Renew APIs, enabling both Individual and Bulk RDs to capture, validate, and pass the reason code to Aether and downstream systems.

## Impact

**OPS** users can select and record standardized reason codes for all RRR actions. The captured reason will be stored, audit-logged, and displayed in the Bundle Overview → Bundle Artefacts table for better visibility and reporting.

## User interface changes

Ops Center

## Known issues and callouts

Below Reason code segregation for Replace, Renew and Reissue is not available in Bulk flow. [example Bulk renew will accept Reason code as Lost] 
reference Bug: SPB-8124
Reason code segregation is available only in single flow - Renew, Reissue, Replace dropdown.
Open Screenshot 2025-12-04 at 5.53.51 PM.png

## Audit logs

Enabled
