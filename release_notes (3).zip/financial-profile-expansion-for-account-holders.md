---
title: Financial Profile Expansion for Account Holders

description: Financial profile expansion is enhanced to capture income and expense details, including type, frequency, and value.

tag: Customer Lifecycle Management

hideAsideIntro: true

---

# Financial Profile Expansion for Account Holders

{{< tag >}}

## Problem statement

The account holder schema stores financial details but limits them to income data, preventing capture of assets or expenses.

## Enhancement

Remodel the financial details object to capture income and expense entries, recording type, frequency, and value.

## Impact

Allows issuers to provide better product recommendations, faster approvals, and tailored services, reducing repetitive data submissions.

## User interface changes

Operations Center and Support Center

## Reports and extracts

Yes

## Audit logs

Disabled
