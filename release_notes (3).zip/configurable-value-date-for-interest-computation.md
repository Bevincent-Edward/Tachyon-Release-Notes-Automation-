---
title: Configurable Value Date for Interest Computation

description: Configurable Value Date for Interest Computation is introduced to allow issuers to set the start date for interest accrual per transaction type.

tag: Revolving Credit Account Processing

hideAsideIntro: true

---

# Configurable Value Date for Interest Computation

{{< tag >}}

## Problem statement

Only the value date is considered for interest computation, preventing issuers from setting alternative start dates such as cycle start or posting dates.

## Enhancement

Value Date Decision Policy is added, allowing issuers to define interest value date behavior per transaction type using posting attributes, voucher codes, and precedence rules.

## Impact

Issuers gain precise control over interest accrual start dates across diverse transaction scenarios, improving regulatory compliance and accuracy of interest calculations.

## User interface changes

Yes, in the Postings tab in Operations Center and Support Center a new column Statement Date which displays the transaction date is also added.

## Known issues and callouts

https://zeta-saas.atlassian.net/browse/SPQ-22149

## Audit logs

Disabled
