---
title: Discretionary DebitCredit Recording in Financial Accounting Workbench

description: Discretionary debit/credit recording is introduced in the Financial Accounting Workbench to provide a safe, validated, and auditable workflow for manual adjustments.

tag: Financial Accounting Workbench

hideAsideIntro: true

---

# Discretionary DebitCredit Recording in Financial Accounting Workbench

{{< tag >}}

## Problem statement

Operations teams lack a standardized, safe, or guided workflow within **FAWB** to post manual adjustments such as refunds, reversals, chargebacks, and dispute-related corrections.

## Enhancement

The enhancement introduces the following:

- Dedicated console in **FAWB** for recording discretionary debit/credit transactions with safety, validation, and auditability
- CoA selection–driven **UI** activation ensures proper context before data entry
- Voucher Code Dropdown
- Dynamic Form Rendering
- Enhanced Ledger Picker

## Impact

Allows users to standardize discretionary transactions across all tenants.

Enables agents to perform **OPS**-initiated adjustments through a unified, controlled system.

## User interface changes

Yes, Operations Center (Optum)

## Known issues and callouts

Aura API version changes from V3 to V1 for Optum zone

## Audit logs

Disabled
